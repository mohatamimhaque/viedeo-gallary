var  list= "A Hypnotizing Toy _ CID (Bengali) - Ep 1277 _ Full Episode _ 12 Feb 2023///A Mysterious Disappearance _ CID (Bengali) - Ep 1282 _ Full Episode _ 17 Feb///A Stained Bridal Cloth - CID - প্রতারণার  আবরণ উন্মোচন (Protaronar Aboron Un///Actor's Mystery _ CID (Bengali) - Ep 1270 _ Full Episode _ 5 Feb 2023///An Incomplete Marriage _ CID (Bengali) - Ep 1286 _ Full Episode _ 21 Feb 202///An Unknown Parcel _ CID (Bengali) - Ep 1265 _ Full Episode _ 1 Feb 2023///Bariwalar Meye _ বাড়িওয়ালার মেয়ে _  Shahed Shahriar _ Farzana Ahsan Mihi _ B///Best of CID (Bangla) - সীআইডী -  Daya And Abhijeet Caught  - Full Episode///Chunnir Jamai Chor _ চুন্নির জামাই চোর _ Afjal Sujon _ Mihi Ahsan _ Samiha A///CID - Copy Cat Serial Killer - Episode 1081 - 25th May 2014///CID (Bengali) -  Forensic Mystery - Part 1 - Ep 1002 - Full Episode - 18th D///CID (Bengali) -  Forensic Mystery - Part 2 - Ep 1003 - Full Episode - 18th D///CID (Bengali) -  Mouse Trap Part- 1 - Ep 1000 - Full Episode - 11th December///CID (Bengali) -  Mouse Trap Part- 2 - Ep 1001 - Full Episode - 12th December///CID (Bengali) - Ep 1090 - 17th July, 2021///CID (Bengali) - Ep 1103 - 8th August, 2021.m4v///CID (Bengali) - Ep 1116 - 15th August, 2021///CID (Bengali) - Ep 1182 _ Full Episode _ 14 August 2022///CID (Bengali) - Full Episode 885 - 16th November, 2019///CID (Bengali) - Full Episode 903 - 15th December, 2019///CID (Bengali) - Full Episode 930 - 2nd February, 2020///CID (Bengali) - Full Episode 931 - 8th February, 2020///CID (Bengali) - Full Episode 934 - 9th February, 2020///CID (Bengali) - Full Episode 935 - 9th February, 2020///CID (Bengali) - Full Episode 941 - 22nd February, 2020///CID (Bengali) - Full Episode 943 - 23rd February, 2020///CID Holi Dhamaka _ CID (Bengali) - Ep 1054 _ Full Episode _ 19 March 2022///CID(Bengali) - Full Episode 705 - 29th December, 2018.m4v///CID(Bengali) - Full Episode 705 - 29th December, 2018///Conspiracy _ CID (Bengali) - Ep 1276 _ Full Episode _ 11 Feb 2023///Daya Solves The Mysteries Of This Hotel _ CID (Bengali) - Ep 1248 _ Full Epi///Disguised Wife _ CID (Bengali) - Ep 1287 _ Full Episode _ 22 Feb 2023.m4a///Disguised Wife _ CID (Bengali) - Ep 1287 _ Full Episode _ 22 Feb 2023.m4v///Disguised Wife _ CID (Bengali) - Ep 1287 _ Full Episode _ 22 Feb 2023///Flight Challenge _ CID (Bengali) - Ep 1275 _ Full Episode _ 10 Feb 2023///Gayab Pati Ka Raaz _ CID (Bengali) - Ep 1273 _ Full Episode _ 8 Feb 2023///Kothay Khuji Tare _ Full Natok _ Musfiq R. Farhan _ Tanjin Tisha _ Mahin _ V///Maa Put Bekkal _ মা পুত ব্যাক্কল  _ Jamil Hossain _ Shamima Naznin _ Affri S.m4a///Maa Put Bekkal _ মা পুত ব্যাক্কল  _ Jamil Hossain _ Shamima Naznin _ Affri S.m4v///Maa Put Bekkal _ মা পুত ব্যাক্কল  _ Jamil Hossain _ Shamima Naznin _ Affri S///Mahasangam - Part 2 _ CID (Bengali) - Ep 1099 _ Full Episode _ 20 March 2022///Mahasangam - Part 3 _ CID (Bengali) - Ep 1101 _ Full Episode _ 26 March 2022///Mahasangam - Part 4 _ CID (Bengali) - Ep 1102 _ Full Episode _ 27 March 2022///My First Love _ মাই ফার্স্ট লাভ _ Musfiq R Farhan _ Keya Payel _ Hridoy _ Ba///Mysterious Incidents On Highway _ CID (Bengali) - Ep 1289 _ Full Episode _ 2///Mystery Behind An Antique Box _ CID (Bengali) - Ep 1288 _ Full Episode _ 23 ///Oti Vokti Chorer Lokkhon _ অতি ভক্তি চোরের লক্ষণ _  New Bangla Natok _ Azmay///Plus Size _ প্লাস সাইজ _ Musfiq R Farhan _ Anika _ Faruk Ahmed _ Mahmud Mahi///Shongshar _ সঙ-সার _ New Bangla Natok 2023 _ Jamil Hossain _ Emu Sikder _ Bo///Shoshur Barir Pera 2 _ শশুর বাড়ির প্যারা ২ _ Natok 2023 _ Sabuj _ Zara _ Ift///Shoshur Barir Pera 3 _ শশুর বাড়ির প্যারা ৩ _ Natok 2023 _ Sabuj _ Zara _ Ift///Taskari _ CID (Bengali) - Ep 1283 _ Full Episode _ 18 Feb 2023///The Warning _ CID (Bengali) - Ep 1272 _ Full Episode _ 7 Feb 2023///The Wedding Day _ CID (Bengali) - Ep 1279 _ Full Episode _ 14 Feb 2023.m4v///The Wedding Day _ CID (Bengali) - Ep 1279 _ Full Episode _ 14 Feb 2023///Theft Of Painting - Part 1 _ CID (Bengali) - Ep 1080 _ Full Episode _ 27 Feb///Uttejito Jamai 2 _ উত্তেজিত জামাই ২ _ Full Natok _ Sabuj Ahmed _ Mumu _ New ///Zehar Ka Kehr _ CID (Bengali) - Ep 1268 _ Full Episode _ 3 Feb 2023///আজ কাজিনের বিয়ে _ Prank King _ Sakib Siddique _ Ananna Islam _ Jamrul Razu _///কাজের বেটি রহিমা _ Kajer Beti Rahima _ Tamim Khandakar _ Saila Sathy _ Valen///গ্রামের চাচাতো ভাই _ Gramer Chachato Bhai _ Shagor Mirza _ Riya Chowdhury _ ///ঠকবাজ _ Thokbaz _ Shamim Hasan Sarkar _ Musfiq Farhan _ Bangla Natok///ডুব সাঁতার _ Doob Shatar _ Valentines Special Natok _ Khairul Basar _ Sadia ///দেশী দালাল _ Desi Dalal _ Bangla Funny Video _ Family Entertainment bd _ Des///ভালোবাসা দিবসের নাটক - ইয়েস স্যার _ Special Drama - Yes Sir - Rashed Shemant///সুন্নতে খাৎনা  _ Prank King _ Miraz Khan _  Arohi Mim _ Mamun Ar Rashid _ Ba///"

//var list ="Bellesa House - Busty Babe Angela White Loves Everything About Mick Blue & [www.yesdownloader.com]///FamilyXXX - Its Big Tit Teen Stepsis Fuck Time (Alexa Payne) [www.saveporn.net]///Horny Teen Stepsis Has Best Natural Big Tits and Gets Fucked Hard By Big Di [www.saveporn.net]///Lucas Fucks His Big Tits stepsister Ella [www.saveporn.net]///MAMACITAZ - Sofia Curly Shows Off Her Body And Rides Some Big Cock Full Sce [www.saveporn.net]///MILF Kagney Linn Karter Huge Exposed Titties [www.saveporn.net]///MODERN-DAY SINS - Sneaky PAWG Kali Roses ALMOST CAUGHT CHEATING By Her Clue [www.saveporn.net]///Natural brunette model Natasha Nice gives a great POV BJ [www.saveporn.net]///NEW SENSATIONS - My Stepsis is Thick, Stacked and Down To Fuck (Karlee Gr [www.saveporn.net]///";
var arr = list.split('///');
var path = 'video';
var thumbnail = 'thumbnail.jpg';
var ext = '.mp4';
var increase = 2;
player(arr,path,thumbnail,ext,increase);

function player(arr,path,thumbnail,ext,increase){
  var i;
  var start = 0;
  var neat = arr.length - 1;

for (i = 0; i < increase+start; i++) {
  const name = arr[i];
  const src = `${path}/${arr[i]}${ext}`;
  $('#wrapper').append(fileLoad(name,thumbnail,src));
}
control();
start = i;
/**/
setInterval(() => {
const last =window.screen.height;
const items = document.querySelectorAll('.video_wrapper');
const last_element = items[items.length - 1].getBoundingClientRect().top + 300;
if(last_element < last){
  if(start < neat){
        for(i=start;i<=increase+start;i++){
          if(i < neat){
          const name = arr[i];
          const src = `${path}/${arr[i]}${ext}`;
          $('#loading_icon').css('display','flex');
          
          $('#wrapper').append(fileLoad(name,thumbnail,src));
          
          } 
          else{
  $('#loading_icon').css('display','none');
}
          }
        start = i;
    }
  control()  ;
}
else{
  $('#loading_icon').css('display','none');
}
},2000)
/*    
*/

function fileLoad(name,thumbnail,src){
  return `<div class="video_wrapper">
            <div class="video_player first_time paused">
              
                <div class="video_status active">

                    <div class="play_arrow">
                        <span class="material-icons">
                            play_arrow
                         </span>
                    </div>
                </div>
                <div class="progress_area mobile">
                    <div class="progress_bar">
                        <span></span>
                    </div>
                    <div class="buffered_progress_bar"></div>
                </div>
                <div class="control_bottom">
                    <div class="timer">
                        <span class="current">0:00</span> / <span class="duration">0:00</span>
                    </div>
                                        <div class="sc-control">
                        <span class="icon" >
                            <i for="fc" class="material-icons fullscreen">fullscreen</i>
             </span>
                        <span class="icon">
                            <i class="material-icons picture_in_picture">picture_in_picture_alt</i>
                        </span>
                    </div>

        
                </div>
                <div class="thumbnail"></div>
                <p class="caption_text"></p>
                <div class="progressAreaTime">0.00</div>
                <div class="spinner">
                    <div class="spinner-child">
                    <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
                        <circle cx="50" cy="50" r="46" />
                    </svg>
                    </div>
                </div>
                <div class="video_overlay">
                           <img src="${thumbnail}" alt="${name}">             

                </div>
                      <video class= 'main_video' src="${src}"></video>
            </div>
                                        <p class="video_title">${name}</p>
        </div>
  
  `
}


//console.log(document.querySelector('#wrapper').innerHTML)
//parent.innerHTHML = output;
//console.log(parrent.innerHTHML);
}