for(let i= 0; i<16; i++){
    $('#loading_icon').append(`<div class="wave ${i}"></div>`)
  }
  $(document).ready(function(){
     $("#scrollBtn").click(function(){
      $('html, body').animate({ scrollTop: '=0px' }, 'slow');})
  })